package com.photapp.api.accounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppApiAccountsApplicationTests {

	@Test
	void contextLoads() {
	}

}
